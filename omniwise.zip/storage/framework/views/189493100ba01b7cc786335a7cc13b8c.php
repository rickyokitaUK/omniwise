<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <script src="<?php echo e(asset('js/gauge.min.js')); ?>"></script>

    
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>
<body>
    
    <?php echo $__env->yieldContent('content'); ?>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\omnitraderapi\resources\views/layouts/app.blade.php ENDPATH**/ ?>