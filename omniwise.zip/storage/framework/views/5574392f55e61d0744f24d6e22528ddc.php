<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Home</title>
  <?php echo app('Illuminate\Foundation\Vite')('resources/js/app.js'); ?>
</head>
<body>
  <div id="app">
    <home></home> 
  </div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\omniwise\resources\views/home.blade.php ENDPATH**/ ?>