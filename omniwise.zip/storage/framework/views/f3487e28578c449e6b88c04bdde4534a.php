<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Login</title>
  <?php echo app('Illuminate\Foundation\Vite')('resources/js/app.js'); ?>
</head>
<body>
  <div id="app">
    <login></login>
  </div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\omniwise\resources\views/login.blade.php ENDPATH**/ ?>