<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>OmniTrader API</title>

    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=instrument-sans:400,500,600" rel="stylesheet" />
</head>
<body class=" text-gray-800 flex items-center justify-center min-h-screen">
<form action="/analyze-images" method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <input type="file" name="images[]" multiple accept="image/*">
    <button type="submit">Upload & Analyze</button>

    <?php if(isset($results)): ?>
    <div class="mt-6 space-y-4 max-w-xl">
        <?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="p-4 border rounded shadow">
                <strong><?php echo e($result['file']); ?></strong>
                <pre class="text-sm text-gray-700 whitespace-pre-wrap mt-2"><?php echo e($result['text']); ?></pre>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php endif; ?>
    
</form>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\omniwise\resources\views/upload.blade.php ENDPATH**/ ?>