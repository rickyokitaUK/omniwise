
<script>
import tradeView from "./TradeView.vue";
import autoTradeView from "./AutoTradeView.vue";
import orderlist from "./OrderList.vue";
import accPropertiesView from "./UserAssetView.vue";
import accountDetailList from "./AccountDetailList.vue";
import { FontAwesomeIcon } from "@fortawesome/vue-fontawesome";
import { useStockStore } from '@/stores/useStockStore'

export default {
  name: "Home",
  components: {
    tradeView,
    autoTradeView,
    orderlist,
    accPropertiesView,
    accountDetailList,
    FontAwesomeIcon,
  },
  data() {
    return {
      activeTab: "trade",
      showDropdown: false,
    };
  },
  methods: {
    handleTabSelect(tab) {
      this.activeTab = tab.name;
    },
    toggleDropdown() {
      this.showDropdown = !this.showDropdown;
    },
    logout() {
      this.$emit("logout");
    },
  },
   setup() {
    const stockStore = useStockStore()

    function selectStock(item) {
      stockStore.setStock(item) // ✅ update global state
    }

    return { selectStock }
  }
};
</script>
<template>
  <div id="home" class="flex flex-col min-h-screen bg-black text-white font-arial">
    <!-- Header -->
    <header
      class="flex items-center justify-between h-16 px-4 border-b border-gray-700 bg-black z-50"
    >
      <!-- Left: Logo + Title -->
      <div class="flex items-center space-x-3">
        <img src="../../assets/images/logo.jpg" class="h-10 w-10" />
        <span class="hidden lg:inline-block font-bold text-lg">Omni Wise</span>
      </div>

      <!-- Middle: Tabs -->
      <div class="flex-1 flex justify-center  items-center overflow-visible">
        <el-tabs v-model="activeTab" @tab-click="handleTabSelect">
          <el-tab-pane name="trade">
            <template #label>
              <img
                class="homeTabItemIcon"
                :src="activeTab === 'trade'
                  ? '../../assets/images/omnitrader_icon_01_on.png'
                  : '../../assets/images/omnitrader_icon_01.png'"
              /> Trade
            </template>
          </el-tab-pane>

          <el-tab-pane name="systemTrade">
            <template #label>
              <img
                class="homeTabItemIcon"
                :src="activeTab === 'systemTrade'
                  ? '../../assets/images/omnitrader_icon_02_on.png'
                  : '../../assets/images/omnitrader_icon_02.png'"
              /> SystemTrade
            </template>
          </el-tab-pane>

          <el-tab-pane name="orderlist">
            <template #label>
              <img
                class="homeTabItemIcon"
                :src="activeTab === 'orderlist'
                  ? '../assets/images/omnitrader_icon_03_on.png'
                  : '../assets/images/omnitrader_icon_03.png'"
              />OrderList
            </template>
          </el-tab-pane>

          <el-tab-pane name="accountoverview">
            <template #label>
              <img
                class="homeTabItemIcon"
                :src="activeTab === 'accountoverview'
                  ? '../assets/images/omnitrader_icon_04_on.png'
                  : '../assets/images/omnitrader_icon_04.png'"
              />Account
            </template>
          </el-tab-pane>

          <el-tab-pane name="accountmanagement">
            <template #label>
              <img
                class="homeTabItemIcon"
                :src="activeTab === 'accountmanagement'
                  ? '../assets/images/omnitrader_icon_05_on.png'
                  : '../assets/images/omnitrader_icon_05.png'"
              />Management
            </template>
          </el-tab-pane>
        </el-tabs>
      </div>

      <!-- Right: Icons + User Menu -->
      <div class="flex items-center space-x-4">
        <font-awesome-icon :icon="['fas', 'circle-question']" />
        <font-awesome-icon :icon="['fas', 'bell']" />

        <div class="relative">
          <button
            id="btn_login"
            @click="toggleDropdown"
            :class="[
              'px-3 py-2 rounded-full border-2 flex items-center',
              showDropdown ? 'border-white' : 'border-transparent'
            ]"
          >
            <font-awesome-icon :icon="['fas', 'user']" />
          </button>
          <div
            v-if="showDropdown"
            class="absolute right-0 mt-2 w-48 bg-gray-900 border border-gray-700 text-white rounded-md shadow-lg"
          >
            <a href="#" class="block px-4 py-2 hover:bg-gray-700">帳戶設定</a>
            <a href="#" class="block px-4 py-2 hover:bg-gray-700">系統設定</a>
            <a href="#" class="block px-4 py-2 hover:bg-gray-700">語言</a>
            <a href="#" class="block px-4 py-2 hover:bg-gray-700" @click="logout">登出</a>
          </div>
        </div>
      </div>
    </header>

    <!-- Main Content -->
    <main class="flex flex-1 overflow-hidden bg-black">
      <tradeView v-if="activeTab === 'trade'" class="flex-1" />
      <autoTradeView v-else-if="activeTab === 'systemTrade'" class="flex-1" />
      <orderlist v-else-if="activeTab === 'orderlist'" class="flex-1" />
      <accPropertiesView v-else-if="activeTab === 'accountoverview'" class="flex-1" />
      <accountDetailList v-else-if="activeTab === 'accountmanagement'" class="flex-1" />
    </main>
  </div>
</template>


<style scoped>
.homeTabItemIcon {
  height: 40px;
}

#btn_login {
  transition: all 0.2s ease;
}

#btn_login:hover {
  border-color: #fff;
}

/* Optional: prevent overflow in tabs */
.el-tabs__header {
  margin: 0 !important;
  background-color: black;
}
</style>
