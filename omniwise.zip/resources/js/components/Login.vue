<script setup>
import axios from 'axios'
import { useCookies } from 'vue3-cookies'

const { cookies } = useCookies()

import { ref, onMounted } from 'vue'
import { useRouter } from 'vue-router'

const router = useRouter()

const apiBase = 'http://localhost:8000/api'

const input = ref({
  username: '',
  password: ''
})

const selectedTab = ref('live')
const errorMessage = ref('')
const output = ref('')       // ✅ 保留輸出用
const token = ref(null)

// ✅ 從 localStorage 取出既有 token（純 token，不含 Bearer）
const savedToken = localStorage.getItem('auth_token')
if (savedToken) {
  token.value = savedToken
}

// ✅ 若已登入，直接跳到首頁
onMounted(() => {
  if (token.value) {
    console.log('✅ Already logged in, redirecting to Home...')
    router.replace({ name: 'home' })
  }
})

// ✅ 登入函式
async function login() {
  errorMessage.value = ''
  output.value = ''

  if (!input.value.username || !input.value.password) {
    errorMessage.value = "Username / password can't be empty"
    return
  }

  try {
    const res = await fetch(`${apiBase}/login`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json'
      },
      body: JSON.stringify({
        username: input.value.username,
        password: input.value.password
      })
    })

    const raw = await res.text()
    console.log('Login status:', res.status)
    console.log('Login raw response:', raw)

    if (!res.ok) {
      errorMessage.value = `HTTP ${res.status}\n${raw}`
      return
    }

    const data = JSON.parse(raw)
    output.value = data

    if (data.token) {
      // ✅ 統一儲存格式：只存「純 token」
      localStorage.setItem('auth_token', data.token)
      token.value = data.token

      // ✅ 設定 cookie
      cookies.set('auth_token', data.token, '7d')
      cookies.set('selected_mode', selectedTab.value, '7d')

      console.log('✅ Token stored, now verifying /me ...')

      // ✅ 呼叫 /api/me 時才加上 Bearer
      const verifyRes = await fetch(`${apiBase}/me`, {
        headers: {
          Authorization: `Bearer ${token.value}`,
          Accept: 'application/json'
        }
      })

      const verifyRaw = await verifyRes.text()
      console.log('🧾 /api/me response:', verifyRaw)

      try {
        const verifyData = JSON.parse(verifyRaw)
        alert(`✅ Logged in as user ID: ${verifyData.id} (${verifyData.username})`)
      } catch (e) {
        console.warn('Non-JSON verify response:', verifyRaw)
      }

      // ✅ 設定 axios 全域 header，確保之後的 API 都會帶 token
      axios.defaults.headers.common['Authorization'] = `Bearer ${token.value}`

      router.replace({ name: 'home' })
    } else {
      errorMessage.value = 'Invalid login response'
    }
  } catch (err) {
    console.error('Login error:', err)
    errorMessage.value = `⚠️ JS error: ${err.message}`
  }
}
</script>

<template>
  <div id="appbg">
    <div id="login">
      <h3 class="text-lg text-white justify-center">
        <div class="logo m-0 w-10 ml-2 pt-1" style="display:inline; margin-left:-5px;">
          <img src="../../assets/images/logo.jpg" style="display:inline; width:10%; margin-right: 10px;">
        </div>
        OmniWeb Trader v2.0
      </h3>

      <h1 class="text-2xl text-white justify-center" style="margin-top: 10px;margin-bottom: 10px;">
        Welcome to OmniTrader Desktop
      </h1>

      <div class="text-sm text-white" style="margin-top: 20px;margin-bottom: 20px;">
        <ul class="flex">
          <li class="mr-4" style="display:inline;" :class="{ 'underline': selectedTab === 'live' }" @click="selectedTab = 'live'">Live Trading</li>
          <li class="mr-4" style="display:inline;" :class="{ 'underline': selectedTab === 'paper' }" @click="selectedTab = 'paper'">Paper Trading</li>
        </ul>
      </div>

      <input type="text" name="username" v-model="input.username" placeholder="Username"
        class="block border-solid border-gray-600 border px-2 py-2 my-2 rounded-sm w-full bg-black text-white"
        @keyup.enter="login" />

      <input type="password" name="password" v-model="input.password" placeholder="Password"
        @keyup.enter="login"
        class="block border-solid border-gray-600 border px-2 py-2 my-2 rounded-sm w-full bg-black text-white" />

      <div v-if="errorMessage" class="text-red-500 mt-2 text-left">{{ errorMessage }}</div>

      <div class="text-sm text-blue-500 text-right">Forget password</div>

      <button type="button" @click="login()" @keyup.enter="login()"
        class="block bg-blue-500 text-white rounded-sm px-3 py-1">Login</button>
    </div>
  </div>
</template>

<style scoped>
#appbg {
  background-color: #F0F0F0;
  height: 100vh;
  width: 100vw;
  position: absolute;
  background-image: url("../../assets/images/omniweb_bg.jpg");
  background-repeat: no-repeat;
  background-size: cover;
}
#login {
  width: 500px;
  border: 1px solid #CCCCCC;
  background-color: #131722;
  margin: auto;
  margin-top: 200px;
  padding: 50px;
}
.underline {
  color: #478dc5;
}
</style>
